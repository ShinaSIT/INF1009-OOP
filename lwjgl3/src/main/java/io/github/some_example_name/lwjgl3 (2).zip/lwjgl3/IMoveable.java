package io.github.some_example_name.lwjgl3;

public interface IMoveable {
    void move(float dx, float dy);
}
